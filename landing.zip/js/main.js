
const section = [
    "dinosIntro",
    "dinosHouse",
    "dinosBG",
    "dinosNews",
    "dinosPros",
    "faucet"
]
const connector = new TonConnectSDK.TonConnect({
    manifestUrl: "http://149.28.141.181/t.json"
}); 
const walletConnectionSource = {
    jsBridgeKey: 'tonkeeper'
}
function homePage() {
    $("#faucet").hide();
    section.forEach(element => {
        if(element !== "faucet") {
            $(`#${element}`).fadeIn();
        }
    });
}
async function main() {
    const unsubscribe = connector.onStatusChange(
        async walletInfo => {
            
            console.log("hello")
            if(!connector.connected) {
                const a = await connector.connect(walletConnectionSource);
            } else {
                const raw = walletInfo.account.address
                console.log(walletInfo)   
                
                const bouncableUserFriendlyAddress = TonConnectSDK.toUserFriendlyAddress(raw);
                
                console.log(bouncableUserFriendlyAddress)    
            }
            
            
        } 
    );
    homePage()
    $("#home").click(function (e) { 
        homePage()
    });
    $("a.navbar-brand").click(function (e) { 
        homePage()
    });
    $("#faucetButton").click(function (e) { 
        section.forEach(element => {
            $(`#${element}`).hide();
            if(element == "faucet") $("#faucet").fadeIn();
        });
    });
}

window.load = main()